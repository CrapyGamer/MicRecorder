# Mic Recorder Android project

This project wraps the supplied Studio Mic Recorder HTML app in an Android WebView. It requests microphone permission at runtime and saves recordings to `Downloads/Mic Recorder` using Android MediaStore.

## Build APK

- Open this project in Android Studio (or import it into a compatible Android IDE).
- Use JDK 17 and Android SDK 35.
- Run `gradle assembleDebug` (or the IDE's Build APK action).
- APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build using GitHub Actions from a phone

1. Create a new GitHub repository and upload all files in this project.
2. Open the repository's **Actions** tab.
3. Select **Build Mic Recorder APK** and tap **Run workflow**.
4. When it finishes, open the run and download the `Mic-Recorder-debug-APK` artifact. Extract it to get `app-debug.apk`.

The generated debug APK is for testing/installing; a release APK should be signed before public distribution.
